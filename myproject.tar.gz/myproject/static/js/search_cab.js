var destination = document.getElementById('destination');
var re_date = document.getElementById('re_date');
var de_date = document.getElementById('de_date');
var cab_type = document.getElementById('cab_type');

destination.addEventListener('blur',function(){
	function Count(string){
		var index=0;
		var count=0;
		while(index < string.length){
			if(string.indexOf(" ")){
				
			}
		}
	}
	if()
});
