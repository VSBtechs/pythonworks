var username = document.getElementById('sign_username');
var fullname = document.getElementById('fullname');
var email = document.getElementById('email');
var phone = document.getElementById('phone');
var address = document.getElementById('address');
var password = document.getElementById('sign_password');
var confirm_password = document.getElementById('con_password');
var signup = document.getElementById('signup');
var error = document.getElementById('error');

username.addEventListener("blur",function(){
	if(username.lenth < 7 ){
		document.getElementById('sign_username').value = "";
	}
},true);

fullname.addEventListener("blur",function(){
	function count(string){
		var c = 0;
		while(string.indexOf(" ") != -1)
		{
			c++;
			string = string.substring(string.indexOf(" ")+1,string.length);
		}
		if(c == 0)return 4;
		return c;
	}
	if(fullname.value.lastIndexOf(" ") == -1 || fullname.value.length <= 7 || count(fullname.value) > 3)
	{	
		document.getElementById("fullname").value = "";
		return;  
	}
	document.getElementById('fullname_error').setAttribute('class','green');
},true);

email.addEventListener("blur",function(){
	var atIndex = email.value.indexOf('@');
	var dotIndex = email.value.lastIndexOf('.');
	if(atIndex == -1 || dotIndex == -1)
	{
		document.getElementById('email').value = "";
		return;
	}
	var hostName = email.value.substring(atIndex+1,dotIndex);
	document.getElementById('email_error1').setAttribute('class','green');
	if(hostName != 'gmail' && hostName != 'yahoomail' && hostName != 'outlook' && hostName != 'live' && hostName != 'hotmail')
	{
		document.getElementById('email').value = "";
		return;
	}	
	document.getElementById('email_error2').setAttribute('class','green');
},true);

phone.addEventListener("blur",function(){
	var p = phone.value;
	if(p.length != 10 || parseInt(p[0]) < 7 )
	{
		document.getElementById('phone').value = "";
		return;
	}
	document.getElementById('phone_error').setAttribute('class','green');
},true);

password.addEventListener("blur",function(){
	console.log(password.value);
	var pattern1 = /[A-Z]/;
	var pattern2 = /[a-z]/;
	var pattern3 = /[0-9]/;
	var pattern4 = /[^A-Za-z0-9]/;
	document.getElementById('password_error1').setAttribute('class','green');
	if(password.value.length < 8 || password.value.indexOf(" ") != -1)
	{
		document.getElementById('sign_password').value = "";
    }
	if(password.value.match(pattern1) && password.value.match(pattern2) && password.value.match(pattern3) && password.value.match(pattern4))
	{ 
		document.getElementById('password_error1').setAttribute('class','green');
		document.getElementById('password_error2').setAttribute('class','green');
		return;
	}
	document.getElementById('sign_password').value = "";
},true);

confirm_password.addEventListener("blur",function(){
	if(confirm_password.value != password.value)
	{
		document.getElementById('con_password').value = "";
		return;
	}
	document.getElementById('confirm_password_error').setAttribute('class','green');
},true);

