#controller module
from .Model.register import Register
from .Model.register import CheckForUsername
from .Model.register import CheckForPhone
from .Model.register import CheckForEmail
from .Model.register import CheckCredentials
from .Model.register import GetSource
from .Model.register import UserData
from .Model.register import ForgotPassword
from .Model.register import GetDestination
from .Model.register import ChangeStatus
from .Model.register import InsertJourney
from .Model.register import CabList
from .Model.register import Update
from datetime import timedelta
from datetime import date
import requests
'''
from Model.register import Register
from Model.register import CheckForUsername
from Model.register import CheckForPhone
from Model.register import CheckForEmail
from Model.register import CheckCredentials
from Model.register import GetSource
from Model.register import UserData
from Model.register import ForgotPassword
from Model.register import GetDestination
from Model.register import ChangeStatus
from Model.register import InsertJourney
from Model.register import CabList
from Model.register import Update
from datetime import timedelta
from datetime import date
import requests
'''


class Auth:
	'''
		This is class which represent Authentication for this system.
	'''
	def SignUp(self,d):
		if Register(Username = d['Username'],Name = d['Name'],Email = d['Email'],Password = d['Password'],Phone = d['Phone'],Address = d['Address'],City = d['City'],Balance = d['Balance'],AccountNo = d['AccountNo']):
			return "{}, your accout has been created, you have to come to our office with required documents. The list of documents and address have been sent via email to {}. ".format(d['Username'],d['Email'])
		else:
			return "500 SERVER ERROR"

	def Login(self,Username,Password):
		if CheckCredentials(Username,Password):
			return True
		else:
			return False


class CabOwner(Auth):
	'''
		This is class which represent Cab Owner for this system.
		Name
		Username
		Password
		Email
		Address
		City
		Phone
	'''
	def __init__(self,**d):
		self.CabOwnerData = d.copy()
		self.CabOwnerData['Balance'] = 0
		self.CabOwnerData['AccountNo'] = "000"

	def AddNewCab(self,):
		CabObject = Cab(self,)

class Customer:
	'''
		This is class which represent Customer for this system.
		Name
		Phone
		Address
		City
	'''
	def __init__(self,**d):
		self.CustomerData = d.copy()

	def CreateJourney(self):
		pass

	def InsertCustomer(self):
		pass

	def Info(self):
		pass

class Journey:
	'''
		This is class which represent Journey for this system.
		JourneyId
		Source
		Destination
		DepartureDate
		ReturnDate
		CarNo
		CustomerId
		BoardingPoint
		Fare
	'''
	def __init__(self,**d):
		self.JourneyData = d.copy()

	def BookCab(self):
		pass

	def CalculateFare(self):
		pass

class Payment:
	'''
		This is a class which represent Payment object for system.
		Mode
		Credentials
	'''
	def __init__(self,mode):
		self.mode = mode
		self.credential = None

	def NetBanking(self):
		pass

	def CardPayment(self):
		pass

class Cab:
	'''
		This is a class which represent Cab Object for system.
		CabOwnerUsername
		CabNo
		RCNo
		Capacity
		Status
		FareInfo
		NameModel
	'''
	def __init__(self,**d):
		self.CabData = d.copy()

	def ChangeStatus(self):
		pass

	def UpdateCabInfo():
		pass
		
def GetListOfCities():
	List = ListSources()
	return List

def UsernameAvailability(username):
	if CheckForUsername(username):
		return True
	else:
		return False

def PhoneAvailability(phone):
	if CheckForPhone(phone):
		return True
	else:
		return False

def EmailAvailability(email):
	if CheckForEmail(email):
		return True
	else:
		return False

def GetUserData(username):
	return UserData(username)

def SendRecoveryMail(email):
	li = ForgotPassword(email)
	if len(li) == 0:
		return False
	else:
		return li


def DestinationList():
	return GetDestination()

def SourceList():
	return GetSource()

def SearchCab(**d):
	Li = list()
	Li = CabList(source = d['source'], destination = d['destination'], cab_type = d['cab_type'])
	if len(Li) == 0:
		return [],0
	else:
		total_distance = distance(d['source'],d['destination'])
		total_distance=1
		date1 = date(int(d['de_date'][2]),int(d['de_date'][0]),int(d['de_date'][1]))
		date2 = date(int(d['re_date'][2]),int(d['re_date'][0]),int(d['re_date'][1]))
		days = (date2-date1).days
		if days == 0:
			days = 1
		for LiElement in Li:
			#return type(LiElement)
			temp1 = LiElement['FarePerKm'] * total_distance + LiElement['DriverAllowance']
			temp2 = days * 250 + LiElement['DriverAllowance']
			if temp2 > temp1:
				LiElement['Fare'] = int(temp2)
			else:
				LiElement['Fare'] = int(temp1) 
			LiElement['Fare'] = LiElement['Fare'] + LiElement['Fare']*0.6
			LiElement['Source'] = d['source']
			LiElement['Destination'] = d['destination']
			LiElement['de_date'] = d['de_date'][2]+"-"+d['de_date'][0]+"-"+d['de_date'][1]
			LiElement['re_date'] = d['re_date'][2]+"-"+d['re_date'][0]+"-"+d['re_date'][1]
			LiElement['CabNumber'] = "".join(LiElement['CabNumber'].split("-"))
		return Li[:],total_distance

def distance(src,dest):
	dist = requests.get('https://maps.googleapis.com/maps/api/distancematrix/json?origins={}&destinations={}&key=AIzaSyDHgcvptI4WKwk0WOhptfxU81kEjh_M8yk'.format(src,dest))
	return int(dist["rows"][1]["elements"][1]["distance"]["text"])

def BookCab(CabNumber):
	if ChangeStatus(CabNumber):
		return True
	else:
		return False
def CreateJourney(**d):
	if InsertJourney(CustomerName = d['CustomerName'],Source = d['Source'],Destination = d['Destination'],de_date=d['de_date'],re_date=d['re_date'],Fare=int(d['Fare']),Paid=int(d['Paid']), CabNumber = d['CabNumber']):
		return True

def UpdateInfo(Username,Field,Value):
		if Update(Username,Field,Value):
			return True
		else:
			return False
