 # Module to register user or cabs.
#
from .database_setup import Session
from .database_setup import CabOwner, Cab, Journey, Customer, City,Payment
from werkzeug.security import generate_password_hash, check_password_hash
import random
from copy import deepcopy

rand = "oHCOHEOFHQCcxhfhaohwchhofwhbohrvctihrlovahwichthhvoahwhohvthohOAXAGWFGCAGIGTIV44646797G64A6ZWSAGYRSWZ46ERWT76W7E7T9F"

session = Session()
def Register(**user):
	#try:
		global session
		user['Password'] = generate_password_hash(user['Password'])
		cab_owner = CabOwner(Username = user['Username'],Name = user['Name'],Email = user['Email']
		,Password = user['Password'],Address = user['Address'],City = user['City'],Phone = user['Phone'],Balance = user['Balance'],AccountNo = user['AccountNo'])
		session.add(cab_owner)
		session.commit()
		return True
	#except:
		return False

def CheckForUsername(username):
	global session
	li = session.query(CabOwner).filter_by(Username = username).first()
	if li == None:
		return True
	else:
		return False

def CheckForEmail(email):
	global session
	li = session.query(CabOwner).filter_by(Email = email).first()
	if li == None:
		return True
	else:
		return False

def CheckForPhone(phone):
	global session
	li = session.query(CabOwner).filter_by(Phone = phone).first()
	if li == None:
		return True
	else:
		return False
	
def CheckCredentials(username,password):
	global session
	List = session.query(CabOwner).filter_by(Username = username).all()
	for ListElement in List:
		if check_password_hash(ListElement.Password,password):
			return True
	return False

def Update(username,field,value):
	global session
	Object = session.query(CabOwner).filter_by(Username = username).one()
	if field == "Password":
		Object.Password = generate_password_hash(value)
	elif field == "AccountNo":
		Object.AccountNo = str(value)
	elif field == "Balance":
		if Object.Balance < value:
			return False
		Object.Balance -= int(value)
	else:
		return False
	session.add(Object)
	session.commit()
	return True

def UserData(username):
	global session
	di = dict()
	Data = session.query(CabOwner).filter_by(Username = username).one()
	di['Username'] = Data.Username
	di['Name'] = Data.Name
	di['Phone'] = Data.Phone
	di['Email'] = Data.Email
	di['City'] = Data.City
	di['Address'] = Data.Address
	di['Password'] = Data.Password
	di['Balance'] = Data.Balance
	di['AccountNo'] = Data.AccountNo
	return di.copy()

def ForgotPassword(email):
	global session
	li = list()
	index = int(random.randint(0,len(rand)-10))
	#print("{} {}".format(index,type(index)))
	temp_password = rand[index:index+10]
	Data = session.query(CabOwner).filter_by(Email = email).first()
	if Data == None:
		return []
	Data.Password = generate_password_hash(rand[index:index+10])
	session.add(Data)
	session.commit()
	li.append(Data.Username)
	li.append(temp_password)
	print(Data.id)
	return li[:]

def GetDestination():
	global session
	Data = session.query(City).all()
	#print(type(Data))
	List = [Li.Name for Li in Data]
	return List[:]

def GetSource():
	global session
	Set = set()
	List = session.query(CabOwner).all()
	for Li in List:
		Set.add(Li.City)
	List = list(Set)
	return List[:]

def CabList(**cab):
	global session   
	li = list()
	li2 = list()            
	List = session.query(CabOwner).filter_by(City = cab['source']).all()
	for Li in List:
		li = session.query(Cab).filter_by(CabOwnerUsername = Li.Username).filter_by(CabType = cab['cab_type']).filter_by(CabStatus = 1).all()
		if li == None:
			continue
		else:
			'''for l in li:
				print(l.__dict__)
				di['CabNumber'] = l.CabNumber
				di['CabName'] = l.CabName
				di['CabType'] = l.CabType
				di['Model'] = l.Model
				di['Fare'] = {'per_km':l.FarePerKm,'driver_allowance':l.DriverAllowance}
				di['Capacity'] = l.Capacity
				di['CabOwnerUsername'] = l.CabOwnerUsername
				di = l
				li.append(di)'''
			li2 += [l.__dict__ for l in li]

	return deepcopy(li2)

def ChangeStatus(CabNumber,):
	global session
	C = session.query(Cab).filter_by(CabNumber = CabNumber).one()
	C.CabStatus = 0
	session.add(C)
	session.commit()
	return True

def InsertJourney(**d):
	global session
	C = session.query(Cab).filter_by(CabNumber = d['CabNumber']).one()
	journey = Journey(SourceCity  = d['Source'],BoardningPoint = s['Source'],DestinationCity = d['Destination'],DepartDate=d['de_date'],ReturnDate = d['re_date'],Fare =d['Fare'],PaidAmount = d['Paid'],Cab = C)
	session.add(journey)
	session.commit()
	return True