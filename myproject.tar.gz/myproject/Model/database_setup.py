from sqlalchemy import create_engine
from sqlalchemy import Column, Integer, String, Boolean, Date, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.orm import sessionmaker
Base = declarative_base()

class City(Base):
	__tablename__ = "City"
	id = Column(Integer,primary_key=True)
	Name = Column(String(30),nullable=False)

class CabOwner(Base):
	__tablename__ = "CabOwner"
	Username = Column(String(30),primary_key=True)
	Name = Column(String(30),nullable=False)
	Email = Column(String(30),nullable=False)
	Password = Column(String(100),nullable=False)
	Address = Column(String(50),nullable=False)
	City = Column(String(20),nullable=False)
	Phone = Column(String(10),nullable=False)
	Balance = Column(Integer,nullable=False)
	AccountNo = Column(String(20),nullable=False)

class Cab(Base):
	__tablename__ = "Cab"
	CabNumber = Column(String(20),primary_key=True)
	CabName = Column(String(20),nullable=False)
	CabType = Column(String(15),nullable=False)
	Model = Column(String(30),nullable=False)
	FarePerKm = Column(Integer,nullable=False)
	DriverAllowance = Column(Integer,nullable=False)
	Capacity = Column(Integer,nullable=False)
	CabStatus = Column(Integer,nullable=False)
	RcNumber = Column(String(20),nullable=False)
	CabOwnerUsername = Column(String(30),ForeignKey('CabOwner.Username'))
	CabOwner = relationship(CabOwner)

class Customer(Base):
	__tablename__ = "Customer"

	id = Column(Integer,primary_key=True)
	Name = Column(String(30),nullable=False)
	Phone = Column(String(10),nullable=False)
	Email = Column(String(50),nullable=False)

class Journey(Base):
	__tablename__ = "Journey"
	id = Column(Integer,primary_key=True)
	SourceCity = Column(String(20),nullable=False)
	DestinationCity = Column(String(20),nullable=False)
	DepartDate = Column(Date,nullable=False)
	ReturnDate = Column(Date,nullable=False)
	BoardingPoint = Column(String(50),nullable=False)
	Fare = Column(Integer,nullable=False)
	PaidAmount = Column(Integer,nullable=False)
	CabNumber = Column(String(20),ForeignKey('Cab.CabNumber'))
	Cab = relationship(Cab)
	CustomerId = Column(Integer,ForeignKey('Customer.id'))
	Customer = relationship(Customer)

class Payment(Base):
	__tablename__ = "Payment"
	id = Column(Integer,primary_key=True)
	JourneyId = Column(Integer,ForeignKey('Journey.id'))
	Journey = relationship(Journey)

def create_database():	
	DBEngine = create_engine("mysql+pymysql://root:root@localhost/BookMyCab")
	Base.metadata.create_all(DBEngine)

def Session():
	engine = create_engine("mysql+pymysql://root:root@localhost/BookMyCab")
	Base.metadata.bind = engine
	DBSession = sessionmaker(bind=engine)
	return DBSession()
