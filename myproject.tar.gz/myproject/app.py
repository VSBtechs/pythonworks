import sys
from flask import Flask
from flask import render_template
from flask import request
from flask import url_for
from flask import redirect
from flask import session
from .controller import CabOwner
from .controller import Auth
from .controller import Cab
from .controller import GetListOfCities
from .controller import UsernameAvailability
from .controller import EmailAvailability
from .controller import PhoneAvailability
from .controller import GetUserData
from .controller import SendRecoveryMail
from .controller import DestinationList
from .controller import SourceList
from .controller import CabOwner
from .controller import SearchCab
from .controller import UpdateInfo
from .controller import BookCab
from .controller import CreateJourney
from functools import wraps
from flask_mail import Mail, Message
import os

User = {}
CabList = []
app = Flask(__name__)
app.secret_key = os.urandom(16)
mail = Mail(app)
app.config.update(
	DEBUG=True,
	#EMAIL SETTINGS
	MAIL_SERVER='smtp.gmail.com',
	MAIL_PORT=465,
	MAIL_USE_SSL=True,
	MAIL_USERNAME = 'bookmycab19@gmail.com',
	MAIL_PASSWORD = 'bookmyoose'
	) 

mail = Mail(app)
def login_required(f):
	try:
		@wraps(f)
		def wrap(*args,**kwargs):
			if 'logged_in' in session or ( request.form['username'] == User['Username'] and request.form['password'] == User['Password']):
				return f(*args,**kwargs)
			else:
				return redirect(url_for(Login))
	except:
		return wrap
	return wrap
@app.route('/forgotpassword/<string:email>/')
def ForgotPassword(email):
	li = SendRecoveryMail(email)
	if len(li) != 0 :
		msg = Message('Recovery Mail From bookmycab',sender='bookmycab19@gmail.com',recipients=[email])
		msg.body = "Your temporary password for {} is {}. Use this to login and change password.".format(li[0],li[1])
		mail.send(msg)
		return "Success"
	else:
		return "Failed"

@app.route('/checkforusername/<string:username>/')
def CheckForUsername(username):
	if UsernameAvailability(username):
		return "available"
	else:
		return "unavailable"

@app.route('/checkforemail/<string:email>/')
def CheckForEmail(email):
	if EmailAvailability(email):
		return "available"
	else:
		return "unavailable"

@app.route('/checkforphone/<string:phone>/')
def CheckForPhone(phone):
	if PhoneAvailability(phone):
		return "available"
	else:
		return "unavailable"

@app.route('/update/<string:Field>/<int:Amount>/')
def Withdraw(Field,Amount):
	global User
	if 'logged_in' in session:
		if UpdateInfo(User['Username'],Field,Amount):
			User = GetUserData(User['Username'])
			return "Success"
		else:
			return "Failed"
	else:
		return "Failed"

@app.route('/update/<string:Field>/<string:Data>/')
def Update(Field,Data):
	global User
	if 'logged_in' in session:
		if UpdateInfo(User['Username'],Field,Data):
			User = GetUserData(User['Username'])
			return "Success"
		else:
			return "Failed"
	else:
		return "Failed"

@app.route('/')
def Index():
	li = SourceList()
	li2 = DestinationList()
	return render_template('index.html',li = li, li2 = li2)

@app.route('/cab/',methods=['GET','POST'])
def Cab():
	global CabList
	if request.method == 'GET':
		return redirect(url_for('Index'))
	if request.method == 'POST':
		source = request.form['source']
		destination = request.form['destination']
		de_date = request.form['de_date']
		de_date = de_date.split("/")
		re_date = request.form['re_date']
		re_date = re_date.split("/")
		cab_type = request.form['cab_type']
		CabList,total_distance = SearchCab(source = source,de_date = de_date,re_date = re_date,destination = destination, cab_type = cab_type)
		return render_template('cab.html',CabList = CabList,total_distance = total_distance)

@app.route('/signup/',methods=['GET','POST'])
def Signup():
	if request.method == 'GET':
		return redirect(url_for('Login'))
	if request.method == 'POST':
		username = request.form['sign_username']
		fullname = request.form['fullname']
		email = request.form['email']
		phone = request.form['phone']
		address = request.form['address']
		city = request.form['city']
		password = request.form['sign_password']
		CabOwnerObject = CabOwner(Username = username,Name = fullname,Email=email,Phone=phone,Address=address,City=city,Password=password)
		response = CabOwnerObject.SignUp(CabOwnerObject.CabOwnerData.copy())
		#msg = Message('Notification Mail',sender='bookmycab19@gmail.com',recipients=[email])
		#msg.body = response
		#mail.send(msg)
		return render_template('signup.html', response = response)

@app.route('/login/',methods=['GET','POST'])
def Login():
	global User
	error = ""
	if request.method == 'GET':
		return render_template('login.html',error=error)
	if request.method == 'POST':
		AuthObject = Auth()
		if AuthObject.Login(request.form['username'],request.form['password']):
			session['logged_in'] = True
			session['username'] = request.form['username']
			User = GetUserData(request.form['username'])
			return redirect(url_for('Usr',username=request.form['username']),307)
		else:
			error = "Invalid username or password."
			return render_template('login.html',error=error)

@app.route('/logout/')
# @login_required
def Logout():
	if 'logged_in' in session:
		session.pop('logged_in',None)
		session.pop('username',None)
		User.clear
	return redirect(url_for('Login'))

@app.route('/usr/<string:username>/',methods=['POST'])
#@login_required
def Usr(username):
	if 'logged_in' in session:
		return render_template('user.html',user = User,username = username)
	else:
		return redirect(url_for('Login'))

@app.route('/payment/<string:CabNumber>/',methods = ['GET','POST'])
def payment(CabNumber):
	global CabList
	if request.method == 'GET':
		return render_template('payment.html',CabNumber = CabNumber)
	if request.method == 'POST':
		CustomerName = request.form['name']
		CustomerPhone = request.form['phone']
		CustomerEmail = request.form['email']
		for Cab in CabList:
			if Cab['CabNumber'] == CabNumber:
				BookCab(CabNumber)
				CreateJourney(CustomerName = CustomerName,Source = Cab['Source'],Destination = Cab['Destination'],
					de_date=Cab['de_date'],re_date=Cab['re_date'],Fare=Cab['Fare'],Paid=Cab['Fare']*0.30, CabNumber = CabNumber)
		return redirect(url_for('Index'))

if __name__ == "__main__":
    app.DEBUG = True
    app.run(host='127.0.0.1', port=5000)
