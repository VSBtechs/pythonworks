import requests  
import json
def distance(src,dest):
	dist = requests.get('https://maps.googleapis.com/maps/api/distancematrix/json?origins={}&destinations={}&key=AIzaSyDHgcvptI4WKwk0WOhptfxU81kEjh_M8yk'.format(src,dest))
	dist_json = json.loads(dist.text)
	dist_km = json.dumps(dist_json)
	dist_km = dist_km[:-2]
	return dist_km
print(distance("bhopal","hoshangabad"))
